<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style1.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header>
        <div class="navbar">``
            <ul>
                <li><a href="#">MEN</a>
                <li><a href="#">WOMEN</a>
                <li><a href="#">KIDS</a></li>
                <li><a href="#">HOME & LIVING</a></li>
                <li><a href="#">BEAUTY</a></li>
                <li><a href="#">STUDIO</a><sup>NEW</sup></li>
            </ul>

        </div>
       
        <div class="searchbox">
            <span class="material-symbols-outlined search_icon">search</span><input
                placeholder="Search for products, brands and more" class="input_bar">
        </div>
        <div class="loginbox">
            <div class="actioncontainer">
                <span name="login_man" class="material-symbols-outlined action_icon">person</span>
                <span name="login_man_name" class="action_name">Profile</span>
                <div class="profile_dropdown"></div>
            </div>
            <div name="mobile_searchbox_name" class="mobile_searchbox actioncontainer">
                <span class="material-symbols-outlined action_icon">search</span>
            </div>
            <div class="actioncontainer">
                <span class="material-symbols-outlined action_icon">favorite</span>
                <span class="action_name">Wishlist</span>
            </div>
            <div class="actioncontainer">
                <span class="material-symbols-outlined action_icon">local_mall</span>
                <span class="action_name">Bag</span>
            </div>
        </div>
    </header>
</body>
</html>