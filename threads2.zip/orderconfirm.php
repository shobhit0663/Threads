<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{ 
           width:100%;
           height: 100vh;
           display: flex;
           justify-content: center;
           align-items: center;
        }
        .container{
            width: 40%;
            height: 35vh;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;


        }
        .no_button{
            width: 10%;
            height: 5%;
            background: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="orderconfirmmail.php" method="POST">
        <h3>
            Please confirm your order
        </h3>
        <div class="no_button">
            <a href="home.php">NO</a>
        </div>
        <input type="submit" name="Yes" value="Yes">
    </form>
    </div>
</body>
</html>
    